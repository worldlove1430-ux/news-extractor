import ipaddress
import socket
from urllib.parse import urlparse

import trafilatura
from flask import Flask, jsonify, render_template_string, request

app = Flask(__name__)

PAGE = """
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>নিউজ এক্সট্র্যাক্টর</title>
<link rel="manifest" href="/static/manifest.json">
<meta name="theme-color" content="#0b5ed7">
<link rel="apple-touch-icon" href="/static/icon-192.png">
<style>
  body { font-family: system-ui, sans-serif; max-width: 760px; margin: 0 auto; padding: 16px; line-height: 1.7; }
  input { width: 100%; padding: 12px; font-size: 16px; box-sizing: border-box; }
  button { padding: 10px 18px; font-size: 16px; margin: 8px 8px 0 0; cursor: pointer; }
  #meta { color: #666; font-size: 14px; margin: 8px 0; }
  #text { white-space: pre-wrap; border: 1px solid #ccc; padding: 12px; border-radius: 8px; min-height: 80px; }
  #msg { color: #b00020; }
</style>
</head>
<body>
<h2>নিউজ লিংক থেকে সংবাদ</h2>
<input id="url" placeholder="এখানে নিউজের লিংক দিন">
<button onclick="go()">নিউজ আনুন</button>
<button onclick="copyAll()">কপি করুন</button>
<p id="msg"></p>
<h3 id="title"></h3>
<div id="meta"></div>
<div id="text"></div>
<script>
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js');
let current = null;
async function go() {
  const url = document.getElementById('url').value.trim();
  const msg = document.getElementById('msg');
  msg.textContent = 'আনা হচ্ছে...';
  try {
    const r = await fetch('/extract?url=' + encodeURIComponent(url));
    const d = await r.json();
    if (!r.ok) { msg.textContent = d.error; return; }
    current = d;
    msg.textContent = '';
    document.getElementById('title').textContent = d.title || '';
    document.getElementById('meta').textContent =
      [d.sitename, d.author, d.date].filter(Boolean).join(' | ');
    document.getElementById('text').textContent = d.text;
  } catch (e) {
    msg.textContent = 'কিছু একটা সমস্যা হয়েছে, আবার চেষ্টা করুন';
  }
}
async function copyAll() {
  if (!current) return;
  const out = (current.title ? current.title + '\\n\\n' : '') + current.text +
              '\\n\\nসূত্র: ' + (current.sitename || '') + ' ' + current.url;
  await navigator.clipboard.writeText(out);
  document.getElementById('msg').style.color = 'green';
  document.getElementById('msg').textContent = 'কপি হয়েছে';
}
</script>
</body>
</html>
"""


def is_safe(url):
    """Only public http/https addresses are allowed."""
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        return False
    try:
        for info in socket.getaddrinfo(p.hostname, None):
            ip = ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
                return False
    except socket.gaierror:
        return False
    return True


@app.route("/")
def home():
    return render_template_string(PAGE)


@app.route("/sw.js")
def sw():
    return app.send_static_file("sw.js"), 200, {"Content-Type": "application/javascript", "Service-Worker-Allowed": "/"}


@app.route("/extract")
def extract():
    url = request.args.get("url", "").strip()
    if not is_safe(url):
        return jsonify(error="লিংকটি সঠিক নয়"), 400

    html = trafilatura.fetch_url(url)
    if not html:
        return jsonify(error="সাইট থেকে পেজ আনা যায়নি"), 502

    data = trafilatura.bare_extraction(html, url=url, include_comments=False)
    if not data:
        return jsonify(error="এই লিংকে খবরের লেখা পাওয়া যায়নি"), 422

    d = data if isinstance(data, dict) else data.as_dict()
    if not d.get("text"):
        return jsonify(error="এই লিংকে খবরের লেখা পাওয়া যায়নি"), 422

    return jsonify(
        url=url,
        title=d.get("title"),
        author=d.get("author"),
        date=d.get("date"),
        sitename=d.get("sitename"),
        text=d.get("text"),
    )


if __name__ == "__main__":
    import os
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
